---
name: context-management-framework
description: >-
  Orient to a workspace when this framework is invoked, discuss its
  adoption or customization, and handle explicit refresh requests for
  established project-context records.
---

# Context Management Framework

## Purpose

Orient to the active workspace using the framework, then discuss or carry out
the user's scoped request. Templates are adaptable starting material.

## Load the framework

For a bare invocation, load [the framework reference](references/framework.md) and perform
the read-only orientation below. For framework discussion/adoption, use that
reference as shared guidance. Reuse framework guidance already available;
refresh workspace facts as needed rather than treating prior chat as current evidence.

For a targeted refresh of established context, start with applicable project
instructions and the affected authoritative records. Consult the framework
when needed to resolve authority, status or maintenance questions.

Read [adoption guidance](references/adoption.md) when planning adoption or reorganization.

Inspect templates only when relevant:

- [Small project](assets/templates/small-project/README.md): minimal documentation.
- [Workspace](assets/templates/workspace/README.md): navigation, shared context and integration responsibilities.
- [Project](assets/templates/project/README.md): independently maintained subprojects or larger standalone projects.
- [Optional records](assets/templates/records/README.md): decisions, procedures, interfaces, run records, checkpoints and handoffs.

For a concrete illustration, read the [small-project example](references/examples/small-project.md)
or [cross-project example](references/examples/change-and-handoff.md) as needed. For question resolution,
see the [uncertainty example](references/examples/uncertainty-discussion.md). All are fictional.

Do not load every template or scan the entire code/asset collection merely to
orient. Start with entry documents and follow relevant authorities. Orientation
is read-only; writing records follows scoped requests and authorized maintenance.

## Default invocation behavior

With no further instructions, begin read-only workspace orientation. Tell the
user that you will inspect the workspace structure and documentation, assess
how context is managed, and study relevant records before continuing.

Start with applicable AGENTS.md instructions, directory structure, README and
context entry points. Follow declared current-state authorities and relevant
requirements, decisions, assumptions and identified unfinished work progressively.
Use actual contents and responsibilities to assess adoption, not exact filenames
or a single marker. Installing the skill or having a README alone does not
establish that the project has adopted the framework.

After initial assessment, tell the user what you found and continue:

- If the framework is established, recognize the existing arrangement and study
  its authoritative context to gain project understanding. Do not propose a new
  structure merely to match templates.
- If an existing project needs adoption/refinement, identify what is already
  covered or missing, including partial adoption. Inspect enough relevant content
  to ground a small proposal, then discuss it and clarify consequential gaps.
- If the workspace is empty or minimally scaffolded, say that it appears to be
  a new project. Confirm the framework is ready to guide work as the purpose and
  scope develop. Establish that purpose before choosing documentation structure;
  do not invent facts or create boilerplate during orientation.

For an existing project, briefly summarize its purpose, authorities, current
selections, verification limits and important open work. Name records actually
read, distinguish gaps/conflicts and ask useful next questions. For a large
workspace without a target task, establish a workspace overview rather than
exhaustively reading every child or choosing an arbitrary checkpoint.

Orientation and discussion do not themselves authorize edits, restructuring or
migration. Follow accompanying instructions within their scope; explicit updates
and already-authorized project maintenance need no additional confirmation.

## Refreshing established context

A direct request to update context or documentation, record decisions, or
prepare a handoff authorizes relevant documentation edits within the established
scope. Clarify only ambiguity that materially affects the update. A later
request to save permits that edit while broader discussion can remain unimplemented.

Follow existing locations and conventions. Saving preserves actual status:
proposals remain proposed, unanswered questions remain unresolved, and accepted
choices are not automatically implemented or verified. Review relevant records;
if already accurate and sufficient, briefly report no changes. A refresh does
not automatically initiate adoption, restructuring, unrelated tests or a full audit.

During authorized work, follow the framework's maintenance routine and adopted
project instructions. Do not ask again about already-authorized updates or
repeat a deferred save offer without a materially new reason.

## Framework understanding

Use the framework reference for record responsibilities and authority.
Keep technical values with their configuration/data owner and preserve
historical input/result identity. Older applicable constraints remain relevant.

Distinguish proposals, selected choices, implementation and verification.
Recommendations and milestones remain proposed until selected on an identifiable
basis; documentation adoption alone does not select engineering priorities.

## Questions and assumptions

An unknown is missing information; a verification gap is missing evidence of
behavior. An assumption is a premise actually adopted for a scoped purpose.
Do not invent assumptions to fill a section. Agreeing to an estimate's use
does not establish its physical truth.

Check available evidence first, then bring consequential gaps into discussion
before dependent implementation. Explain the impact and seek an answer or an
agreed provisional approach. Consolidate related questions where practical;
routine choices within the authorized scope need no extra approval.

Keep skipped or unanswered questions unresolved; silence does not approve
an estimate. Continue independent work, but leave dependent work pending if
no adequate input or agreed provisional approach exists.

Surface new issues when discovered, including during implementation or final
review. Discuss material effects, then update the owning records and affected
conclusions when authorized to save or implement. Preserve old run inputs.
Do not repeatedly reopen a deferred question without new relevance or evidence.

## Discussion and customization

Follow the user's current objective rather than forcing a fixed adoption sequence.

Discussion can alternate between explanation, inspection and revisions.
Keep facts, defaults, proposals, choices and implementation authorization
distinct. During discussion-only use, keep proposals in chat unless saving is authorized.

Customize the structure to project size, existing conventions, maintenance
needs and dependencies. Prefer the smallest structure that provides useful
ownership, context and history. Present a small useful first pass before
broader cleanup when appropriate; explain any necessary additional structure.

Small projects can combine responsibilities in README or CONTEXT. Split
records when maintenance/navigation warrants it. Preserve useful existing
names and authorities; do not duplicate state or indexes to match templates.

Keep agreed adaptations clear as the conversation develops. Explain
consequences when an adaptation changes information ownership, historical
traceability or cross-project responsibilities.

## Workspace inspection

Read-only orientation is the default on bare invocation and a normal prerequisite
for workspace-specific discussion. Inspect relevant files without waiting for a
second request to read. Respect any explicit user limits on the reading scope.

Start with instructions, entry points and structure; follow relevant references
progressively. Inspect code, assets or generators only to resolve a specific
issue. Report evidence and limits; notes alone cannot establish a live machine's state.

Use non-mutating inspection. Do not run builds, tests, generators or cache-writing
commands merely to orient. When checking Git status, use --no-optional-locks or
an equivalent read-only approach that avoids refreshing the index.

## Preparing implementation

When planning adoption or structural changes, make the proposal concrete:

- Show the intended layout and information ownership.
- Identify files to create, edit, merge or move.
- Explain how existing history and references will be preserved.
- Identify affected documentation generators and consumers.
- State unresolved choices and appropriate verification.

Agreement with a proposed design does not by itself authorize file changes.
Proceed when the user instructs implementation.

If implementation of an agreed plan is already authorized, continue within
that scope without requiring repeated confirmation or a special phrase.

## Implementation

Apply the agreed adaptations and preserve unrelated work.

Resolve material ambiguity before making dependent changes. If inspection
reveals a significant departure from the agreed plan, explain it and discuss
the affected scope.

Check changed references, ownership consistency and relevant generators.
Do not rerun unrelated engineering checks for a documentation migration.

Report what changed, what was checked and what remains unresolved.

The resulting project documentation and agent instructions should support
ordinary maintenance without requiring this skill on every task.

## Customization scope

Keep local adaptations in their workspace. Update the reusable framework,
templates or installed skill only when that broader change is requested.
Maintain one editable source and publish one current installed copy.

Documentation adoption does not itself configure client integrations.
