# Working instructions for {{PROJECT_NAME}}

Template source: adopt and fill these instructions before using them as live project guidance.

## Scope and entry points

- This scope owns {{OWNED_COMPONENTS}}. Maintainer: {{MAINTAINER_OR_ROLE}}.
- Follow applicable workspace instructions when nested. Keep this file focused on additions specific to this project.
- Read README.md and context/README.md, then the declared current-state authority, requirements and relevant decisions/assumptions.
- Actual values belong to their configuration/data owner. Verify the source rather than copying another project's summary.
- Current user instructions and applicable higher-priority instructions govern the task; a historical plan is not authorization for new actions.

## Execution and documentation

- Establish the real working state and task scope before changes. Preserve unrelated/concurrent work.
- Identify durable changes during authorized work and update their owning records at coherent work, verification or handoff boundaries. Bring updates forward when explicitly requested; record consequential corrections before dependent work proceeds. Preserve basis, scope, status and evidence, following the latest user limits.
- Check evidence and discuss consequential gaps before dependent work; surface new issues when discovered. Keep skipped questions unresolved and continue independent work. Record adopted premises separately from unknowns; agreement to use an estimate does not validate it. Reopen deferred questions only when newly relevant.
- Update current state only for actual selection, implementation or verification changes. Keep obsolete milestone narrative in history.
- Keep current operational instructions consistent with the selected configuration.
- Check affected consumers when changing a shared input/interface. Record impact and required follow-up; do not relink old results to new inputs.
- Use the exact identified task checkpoint if needed. Maintain it near its owning project and keep concurrent workstreams separate.
- Perform appropriate checks once, record results and evidence, and repeat only when changes/failures/uncertainty justify it.
- If affected records are already accurate and sufficient, report no changes without timestamp churn or activity-only log entries. Record meaningful new evidence or requested reviews, and add history only when worth retaining. Do not manufacture pass results/approvals or ask again about authorized updates.
- Refer to older still-applicable requirements and decisions as needed; current context is not defined by recency alone.

## Commands and local conventions

Working directory: {{WORKING_DIRECTORY}}  
Build/run: {{COMMAND_OR_NOT_APPLICABLE}}  
Checks: {{COMMANDS_AND_VERIFICATION_SCOPE_OR_NOT_APPLICABLE}}  
Units/frame/time conventions: {{CONVENTION_SOURCE}}  
External inputs: {{OWNER_AND_VERSION_REFERENCES}}  
Preservation requirements: {{REQUIREMENT_REFERENCES}}

Unfilled fields are not executable instructions.

