# {{PROJECT_NAME}}

Template status: unfilled.  
Project ID: {{PROJECT_ID}}  
Maintainer: {{MAINTAINER_OR_ROLE}}  
Parent workspace: {{WORKSPACE_REFERENCE_OR_STANDALONE}}

## Purpose and scope

{{PROJECT_OBJECTIVE}}

Owns: {{OWNED_COMPONENTS_DATA_AND_INTERFACES}}  
Consumes: {{EXTERNAL_INPUTS_AND_OWNERS}}  
Provides: {{OUTPUTS_AND_CONSUMERS}}

## Read and use

1. [Working instructions](AGENTS.md).
2. [Context index and authority map](context/README.md).
3. [Current state](context/current_state.md) and [requirements](context/requirements.md).
4. Relevant [decisions](context/decisions/README.md), [assumptions](context/assumptions.md) and [technical records](context/docs/README.md).

Implementation entry: {{ENTRY_POINT}}  
Configuration/data authority: {{CONFIGURATION_OR_SOURCE_LOCATION}}  
Environment/dependencies: {{ENVIRONMENT_REFERENCE}}  
Working directory: {{WORKING_DIRECTORY}}  
Run/build: {{COMMAND_OR_NOT_APPLICABLE}}  
Verification: {{COMMAND_AND_SCOPE_OR_NOT_APPLICABLE}}

Commands are authoring placeholders. Replace them before use.

## State and history

The current-state record owns selection and verification status. This overview does not independently maintain installed versions, selected releases or parameter values.

[Dated work history](context/logs/work-log.md) records actual changes and outcomes. Identify any optional task checkpoint in the context index; task execution details do not belong in the project overview.

## Storage and version identity

Source/history arrangement: {{PARENT_REPOSITORY_OR_INDEPENDENT_REPOSITORY_OR_OTHER}}  
Separately stored assets/evidence: {{LOCATION_VERSION_AND_ACCESS_INSTRUCTIONS_OR_NONE}}

A reference to an external file does not copy that file into this project.

