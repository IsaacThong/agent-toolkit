# {{PROJECT_NAME}} context index

Template status: unfilled.  
Owner scope: {{PROJECT_ID}}  
Maintainer: {{MAINTAINER_OR_ROLE}}  
Updated: {{UPDATED_AT}}

## Purpose and background

{{CONCISE_BACKGROUND_AND_SYSTEM_BOUNDARY}}

This index routes readers to authoritative records. It does not repeat current selections or technical parameter values.

## Reading order

1. [Current state](current_state.md).
2. [Applicable requirements](requirements.md).
3. Relevant [decision records](decisions/README.md) and [assumptions](assumptions.md).
4. The task's identified checkpoint, if present.
5. Relevant [technical documentation](docs/README.md), run records and evidence.

Read [the work log](logs/work-log.md) when historical sequence matters; it is not a list of current instructions.

## Authority map

| Information | Owning record/source |
| --- | --- |
| Present selection/status | [current_state.md](current_state.md) |
| Requirements/constraints | [requirements.md](requirements.md) |
| Decision rationale | [Decision register](decisions/README.md) and its linked records |
| Assumption basis and validation needs | [assumptions.md](assumptions.md) |
| Parameter values/units | {{OWNING_CONFIGURATION_OR_DATA_REFERENCE}} |
| Interface contracts | {{CANONICAL_INTERFACE_REFERENCE_OR_NOT_YET_DEFINED}} |
| Evidence and run identity | {{EVIDENCE_OR_RUN_RECORD_LOCATION}} |
| Agent procedure | [../AGENTS.md](../AGENTS.md) |
| Change history | [logs/work-log.md](logs/work-log.md) |

If an existing JSON manifest is authoritative for current state, declare it here and use the Markdown state file only as a pointer or generated view.

## Context that remains important

- Project-wide constraints: identify the active requirement IDs relevant across tasks.
- Significant accepted/rejected decisions: identify records that future work should consult.
- Open assumptions and known limitations: identify their owning entries.
- Shared interfaces/conventions: identify the owner and source.

Important references: {{RECORD_IDS_AND_PATHS_OR_NOT_YET_SELECTED}}

Use references to the original records; do not maintain another independent narrative of their facts. Older records remain relevant according to scope/status, not simply their age.

## External dependencies and consumers

| Producer/consumer | What crosses the boundary | Owning source/interface | Revision policy |
| --- | --- | --- | --- |
| {{PROJECT_ID_OR_NONE}} | {{INPUT_OR_OUTPUT}} | {{SOURCE}} | {{PINNED_REVISION_OR_EXPLICIT_SELECTION_POLICY}} |

## Active work

Task IDs and checkpoint paths: {{TASK_REFERENCES_OR_NONE}}

Task checkpoints are optional. A new thread/task must identify its relevant task explicitly; do not select whichever checkpoint was most recently edited.

