# {{PROJECT_NAME}} assumptions

Template status: unfilled.  
Owner scope: {{PROJECT_ID}}  
Maintainer: {{MAINTAINER_OR_ROLE}}  
Updated: {{UPDATED_AT}}

This register owns the basis, uncertainty and validation needs of assumptions. Values and units remain in their owning configuration/data source.

Record only premises actually adopted for a purpose. Keep unanswered questions and verification gaps in current state; omit unused entries. Agreement to use an estimate does not validate its truth.

## Assumptions

### ASM-{{PROJECT_ID}}-001 — {{TITLE}}

Status: unverified  
Assumption: {{PREMISE_BEING_USED}}  
Scope and conditions: {{APPLICABILITY}}  
Parameter/input reference: {{CONFIGURATION_FIELD_OR_SOURCE_OR_NOT_APPLICABLE}}  
Basis: {{MEASUREMENT_ESTIMATE_DERIVATION_OR_HYPOTHESIS_REFERENCE}}  
Uncertainty and known limits: {{LIMITS}}  
Consumers/results using it: {{REFERENCES_OR_NOT_IDENTIFIED}}  
Validation needed: {{METHOD_CONDITIONS_AND_ACCEPTANCE_CRITERION}}  
Evidence and verified conditions: {{REFERENCE_OR_NOT_VALIDATED}}  
Last assessed: {{DATE_OR_NOT_ASSESSED}}  
Supersedes/superseded by: {{ID_OR_NONE}}

Suggested status: unverified, supported, falsified, superseded.

Supported means evidence exists within the recorded conditions. Accepting a design does not validate its assumptions. If an assumption is falsified, identify affected consumers and annotate their conclusions; preserve the actual inputs used by historical runs.

