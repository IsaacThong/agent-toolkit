# {{PROJECT_NAME}} current state

Template status: unfilled; no present configuration has been established by this starter.  
Owner scope: {{PROJECT_ID}}  
Maintainer: {{MAINTAINER_OR_ROLE}}  
Record updated: {{UPDATED_AT}}  
State authority: this file, unless the context index declares an existing manifest instead.

## Present selection

| Item | Current selection | Source/revision |
| --- | --- | --- |
| Code/build/configuration | {{SELECTION_OR_UNKNOWN}} | {{IDENTITY_OR_NOT_RECORDED}} |
| Asset/data entry point | {{ENTRY_OR_NOT_APPLICABLE}} | {{VERSION_HASH_OR_NOT_RECORDED}} |
| Environment | {{ENVIRONMENT_OR_UNKNOWN}} | {{REFERENCE}} |

Parameter values remain in the owning configuration/data. Record selection here without reproducing its entire contents.

## Implementation and experiments

| Capability/candidate | Present status | Evidence/reference |
| --- | --- | --- |
| {{CAPABILITY}} | {{PLANNED_EXPERIMENTAL_IMPLEMENTED_SELECTED_RELEASED_OR_UNKNOWN}} | {{SOURCE_OR_NOT_RECORDED}} |
| {{EXPERIMENT_OR_NONE}} | {{EXPERIMENT_STATUS}} | {{DECISION_OR_RUN_REFERENCE}} |

An active experiment is not automatically the selected release.

## Verification

| Scope | Exact revision/input | Result | Verified when/by | Evidence and limits |
| --- | --- | --- | --- | --- |
| {{CHECK_SCOPE}} | {{REVISION_OR_UNKNOWN}} | not run | not recorded | {{EVIDENCE_OR_NONE}} |

An edit date is not a verification date. A successful build/import does not establish runtime or physical behavior.

## Open questions, limitations and blockers

{{OPEN_QUESTIONS_LIMITATIONS_OR_NOT_ASSESSED}}

Reference adopted premises from the assumption register separately. Missing information or an unperformed check alone does not create an assumption. Keep deferred questions unresolved with their impact; do not mark them as established facts.

## Dependencies

| Owning project | Input/interface | Selected revision | Availability |
| --- | --- | --- | --- |
| {{PRODUCER_ID_OR_NONE}} | {{SOURCE_REFERENCE}} | {{REVISION_OR_UNKNOWN}} | {{LOCAL_SHARED_OR_UNAVAILABLE}} |

## Next project milestone

{{MILESTONE_AND_DEPENDENCIES}}

Status and basis: {{PROPOSED_OR_SELECTED_AND_SOURCE}}

Specific unfinished commands and intermediate edits belong in an optional task checkpoint. Keep historical milestones in the work log rather than accumulating obsolete current statements here.

