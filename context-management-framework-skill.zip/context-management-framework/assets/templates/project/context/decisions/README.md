# {{PROJECT_NAME}} decision register

Owner scope: {{PROJECT_ID}}  
Maintainer: {{MAINTAINER_OR_ROLE}}

No accepted decisions are established by this starter.

## Records

| ID | Topic | Record location | Affected scopes |
| --- | --- | --- | --- |
| {{DECISION_ID}} | {{TITLE}} | {{RECORD_PATH}} | {{SCOPES}} |

Use a separate identified record for consequential choices. A small project can keep short decisions in its README instead.

Individual decision records own their status, rationale and supersession. This index is navigation; it does not maintain another independent decision summary.

Suggested filename: DEC-{{PROJECT_ID}}-001-short-topic.md. The framework's optional decision template supplies the fields.

## Use

Consult applicable records even when old. A proposed or rejected option must not silently become an accepted configuration. When changing a decision, explain the change and identify affected consumers, evidence and the superseded record.

