# {{PROJECT_NAME}} technical records

Owner scope: {{PROJECT_ID}}  
Maintainer: {{MAINTAINER_OR_ROLE}}

Use this directory for detailed topic explanations, research, procedures, run reports and interface contracts where a separate record is useful.

## Index

| Topic/record ID | Purpose | Canonical location |
| --- | --- | --- |
| {{TOPIC_OR_RECORD_ID}} | {{PURPOSE}} | {{PATH}} |

A procedure can instead live beside its tool as a tool README. Declare that location as canonical and link to it; do not maintain two independent operating instructions.

## Record expectations

- Identify owner, scope, document status and source/evidence references.
- Separate current instructions from dated historical analysis.
- Identify actual inputs/configuration/environment for results.
- Distinguish observations, assumptions, interpretation, proposals and completed work.
- Record validation limits and supersession/correction where necessary.
- Keep raw generated output in the appropriate output/evidence location.

The framework supplies optional technical-note, procedure, run-record and interface templates. Add only the record types the project needs.

