# {{PROJECT_NAME}} work log

Owner scope: {{PROJECT_ID}}  
Maintainer: {{MAINTAINER_OR_ROLE}}

Record meaningful dated actions and outcomes. This is historical sequence, not current instructions. Current state, decision rationale, assumptions and parameter values retain their declared owners.

No completed work is recorded by this starter.

## Entry format

~~~text
Date/time and timezone:
Task / actor:
Outcome: documented / proposed / implemented / verified / failed / other
Change: previous state -> resulting state
Reason / requirement / decision reference:
Checks actually performed and evidence:
Input/configuration/code identity:
Remaining work:
Recovery/correction reference, if applicable:
~~~

Link detailed records rather than duplicating them. Annotate consequential corrections explicitly. A separate release CHANGELOG is optional when recipients need a concise release history.

