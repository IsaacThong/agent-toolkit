# {{PROJECT_NAME}} requirements

Template status: unfilled.  
Owner scope: {{PROJECT_ID}}  
Maintainer: {{MAINTAINER_OR_ROLE}}  
Updated: {{UPDATED_AT}}

Record obligations and constraints, not every proposed implementation. Parameter values remain in their declared specification/configuration.

## Applicable parent requirements

Parent/workspace source and IDs: {{REFERENCES_OR_STANDALONE}}

A shared requirement applies only within its declared scope. Record an explicit reconciliation for conflicts rather than silently changing another owner's requirement.

## Project requirements

### REQ-{{PROJECT_ID}}-001 — {{TITLE}}

Status: proposed  
Requirement: {{OBLIGATION}}  
Scope/conditions: {{APPLICABILITY}}  
Source/basis: {{USER_INSTRUCTION_SPECIFICATION_OR_OTHER_SOURCE}}  
Acceptance criterion: {{OBSERVABLE_CRITERION}}  
Verification reference/status: {{EVIDENCE_OR_NOT_PERFORMED}}  
Affected components/consumers: {{REFERENCES}}  
Supersedes/superseded by: {{ID_OR_NONE}}

Suggested status: proposed, active, superseded, retired.

Older active constraints remain applicable until explicitly changed. Activation does not mean implementation or acceptance testing has succeeded.

