# Optional record templates

These are blank authoring templates, not implemented project records. Copy only those needed into the owning project, replace placeholders and remove unused fields.

| Template | Use when | Typical destination |
| --- | --- | --- |
| [Decision](decision.md) | A consequential choice needs traceable rationale | context/decisions/DEC-SCOPE-001-topic.md |
| [Assumption](assumption.md) | One assumption needs more space than a register entry | An identified assumption record referenced by the register |
| [Technical note](technical-note.md) | A topic, investigation or method needs explanation | context/docs/topic.md |
| [Procedure](procedure.md) | Someone needs repeatable operating instructions | context/docs/ or the owning tool README |
| [Run record](run-record.md) | A result needs identifiable inputs, method and evidence | The owning experiment/run documentation |
| [Interface](interface.md) | Projects exchange data, commands, assets or conventions | One named canonical contract |
| [Checkpoint](checkpoint.md) | Substantial unfinished execution needs an exact stopping point | context/tasks/TASK-SCOPE-001/CHECKPOINT.md |
| [Work-log entry](work-log-entry.md) | A meaningful action/outcome needs a dated history entry | Append/adapt inside the owning work log |
| [Release handoff](release-handoff.md) | A versioned result is handed to another person/machine | Release/handoff documentation |

A small project's README sections can hold the same information. Splitting a record does not make it a second authority: replace the old full copy with a reference.

## Use rules

- Establish the logical owner and source of each claim.
- Keep current selection, decision acceptance, implementation and verification separate.
- Give important records stable IDs and explicit scope/status.
- Keep literal parameter values in the owning configuration/data unless the record is itself the identified measurement source.
- Mark missing evidence, unknown values and unperformed checks honestly.
- Historical records retain the revisions/inputs actually used.
- A checkpoint is optional task state, not the sole store of decisions and requirements.
- These templates contain no hooks or client automation.

