# ASM-{{SCOPE_ID}}-001 — {{TITLE}}

Template status: unfilled.  
Owner scope: {{SCOPE_ID}}  
Maintainer: {{MAINTAINER_OR_ROLE}}  
Updated: {{UPDATED_AT}}  
Assumption status: unverified

Use this optional record only for a premise actually adopted for a scoped purpose. Unanswered questions and verification gaps belong in owning current state. Do not create an assumption merely to fill a template; permission to use an estimate is distinct from validation.

## Premise and applicability

Assumption: {{PREMISE}}  
Scope/conditions: {{APPLICABILITY}}  
Configuration parameter/input reference: {{CANONICAL_REFERENCE_OR_NOT_APPLICABLE}}

## Basis and uncertainty

{{MEASUREMENT_ESTIMATE_DERIVATION_OR_HYPOTHESIS_AND_LIMITS}}

Do not independently maintain a parameter value here when its value belongs to a configuration/data source.

## Consumers and consequences

Methods/components/runs relying on this: {{REFERENCES}}  
Consequences if false: {{IMPACT}}

## Validation

Needed method and acceptance conditions: {{METHOD}}  
Performed validation/evidence: {{REFERENCE_OR_NOT_PERFORMED}}  
Conditions actually supported: {{CONDITIONS_OR_NOT_ESTABLISHED}}  
Last assessed: {{DATE_OR_NOT_ASSESSED}}

## Supersession/correction

Supersedes: {{ID_OR_NONE}}  
Replacement: {{ID_OR_NONE}}  
Affected conclusions and follow-up: {{REFERENCES_OR_NOT_IDENTIFIED}}

Suggested status: unverified, supported, falsified, superseded. Support is limited to recorded conditions.

