# TASK-{{SCOPE_ID}}-001 — {{TASK_TITLE}}

Template status: unfilled. This record is optional unfinished execution state.  
Owner scope: {{SCOPE_ID}}  
Current editor/thread/workstream: {{IDENTITY}}  
Updated: {{UPDATED_AT}}  
Task status: planned  
Mode: {{DISCUSSION_IMPLEMENTATION_REVIEW_OR_VALIDATION}}

## Objective and completion criteria

{{CURRENT_USER_OBJECTIVE_AND_OBSERVABLE_COMPLETION}}

## Applicable constraints and decisions

{{REQUIREMENT_DECISION_ASSUMPTION_IDS_AND_SOURCE_REFERENCES}}

Include a short reminder where useful, but keep enduring engineering facts in their authoritative records. A historical instruction does not authorize a new action.

## Working state

Project and working directory: {{PATH}}  
Selected input/configuration revisions: {{REFERENCES}}  
Files changed and relevant uncommitted state: {{PATHS_AND_IDENTITIES}}  
Pending processes/commands: {{IDENTIFIERS_STATUS_AND_HOW_TO_CHECK_OR_NONE}}

## Progress

Completed: {{COMPLETED_STEPS_OR_NONE}}  
In progress/stopping point: {{PRECISE_STATE}}  
Pending: {{REMAINING_STEPS}}  
Rejected/failed approaches: {{REFERENCES_AND_REASONS_OR_NONE}}

## Verification already performed

{{COMMAND_METHOD_RESULT_REVISION_DATE_AND_EVIDENCE_OR_NOT_RUN}}

Rerun only when relevant changes, failure or uncertainty justify it.

## Resume

Immediate next action: {{ACTION_OR_WAITING_CONDITION}}  
Read first: {{RELEVANT_SOURCE_PATHS}}  
Blockers/questions: {{ITEMS_OR_NONE}}  
Handoff/completion reference: {{REFERENCE_OR_NOT_COMPLETE}}

Suggested task status: planned, active, waiting, paused, complete. Record the actual task state.

Keep the record compact. Give independent workstreams separate IDs/checkpoints. On completion, update durable state/decision/history records as appropriate and mark/archive this checkpoint. It is not the only store of project knowledge and is not a compaction implementation.

