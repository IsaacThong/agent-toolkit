# DEC-{{SCOPE_ID}}-001 — {{TITLE}}

Template status: unfilled.  
Owner scope: {{SCOPE_ID}}  
Maintainer: {{MAINTAINER_OR_ROLE}}  
Record updated: {{UPDATED_AT}}  
Decision status: proposed  
Decision date: {{DATE_OR_NOT_DECIDED}}

## Question and context

{{PROBLEM_REQUIREMENTS_AND_SCOPE}}

## Decision

{{PROPOSED_OR_ACTUAL_CHOICE}}

Basis/source: {{USER_CHOICE_SCOPED_DESIGN_DECISION_OR_EXTERNAL_REQUIREMENT}}  
Acceptance evidence or authority: {{REFERENCE_OR_NOT_ACCEPTED}}  
Implementation/state reference: {{REFERENCE_OR_NOT_IMPLEMENTED}}

A proposal, an accepted choice, an implementation and a validated result are separate states.

## Alternatives and rationale

| Alternative | Benefits and costs | Reason selected or not selected |
| --- | --- | --- |
| {{OPTION}} | {{TRADE_OFFS}} | {{REASON_OR_UNDECIDED}} |

## Evidence and assumptions

Evidence and source revision/date: {{REFERENCES}}  
Assumption IDs and remaining uncertainty: {{REFERENCES_OR_NONE_IDENTIFIED}}

## Consequences and affected consumers

{{IMPACT_OWNERS_INTERFACES_FOLLOW_UP_AND_REVERSIBILITY}}

Verification needed/performed: {{SCOPE_AND_EVIDENCE_OR_NOT_RUN}}

## Supersession and corrections

Supersedes: {{ID_OR_NONE}}  
Superseded by: {{ID_OR_NONE}}  
Correction/withdrawal reason: {{REFERENCE_OR_NOT_APPLICABLE}}

Suggested status: proposed, accepted, rejected, superseded, withdrawn. Preserve the rationale and historical input identity where useful.

