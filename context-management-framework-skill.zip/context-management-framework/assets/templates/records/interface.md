# {{INTERFACE_ID}} — {{INTERFACE_TITLE}}

Template status: unfilled.  
Canonical owner: {{OWNER_SCOPE}}  
Maintainer: {{MAINTAINER_OR_ROLE}}  
Contract status: draft  
Contract version: {{VERSION_OR_UNASSIGNED}}  
Updated: {{UPDATED_AT}}

## Producer, consumers and responsibility

Producer: {{PROJECT_AND_ENTRY_POINT}}  
Consumers: {{PROJECTS_AND_ENTRY_POINTS}}  
Each side's responsibilities: {{RESPONSIBILITIES}}

## Data/command/asset contract

Schema, file/topic/API and meaning: {{DEFINITION_OR_REFERENCE}}  
Units and parameter authority: {{OWNER_AND_CONFIGURATION_REFERENCES}}  
Coordinates/origin/axis conventions: {{REFERENCE_OR_NOT_APPLICABLE}}  
Time/clock/rate conventions: {{REFERENCE_OR_NOT_APPLICABLE}}  
Availability/storage/transport: {{REFERENCE}}  
Failure/missing/stale-input behavior: {{BEHAVIOR}}

Do not duplicate producer-owned numerical values without an explicit versioned snapshot or consumer override.

## Versioning and compatibility

{{IDENTITY_COMPATIBILITY_RULES_AND_CHANGE_NOTIFICATION_OR_REVIEW_PROCESS}}

## Validation

Producer checks: {{EVIDENCE_OR_NOT_PERFORMED}}  
Consumer checks: {{EVIDENCE_OR_NOT_PERFORMED}}  
Integrated verification and exact revisions: {{EVIDENCE_OR_NOT_PERFORMED}}  
Known limits: {{LIMITS}}

## Decisions and affected records

{{REQUIREMENT_DECISION_ASSUMPTION_AND_RUN_REFERENCES}}

A producer's isolated success is not proof that every consumer or integrated composition works.

