# {{PROCEDURE_TITLE}}

Template status: unfilled.  
Owner scope: {{SCOPE_ID}}  
Maintainer: {{MAINTAINER_OR_ROLE}}  
Procedure status: draft  
Updated: {{UPDATED_AT}}  
Applies to: {{ACTUAL_COMPONENT_VERSION_ENVIRONMENT_AND_CONDITIONS}}

## Purpose and scope

{{EXPECTED_OUTCOME_AND_BOUNDARY}}

Canonical procedure location: {{THIS_FILE_OR_OTHER_OWNER}}

## Prerequisites and working state

{{INPUTS_DEPENDENCIES_WORKING_DIRECTORY_CURRENT_STATE_AND_ACCESS_REQUIREMENTS}}

## Steps

1. {{STEP_AND_EXPECTED_OBSERVATION}}
2. {{STEP_AND_EXPECTED_OBSERVATION}}

Commands, if any:

~~~text
{{ACTUAL_COMMANDS_AFTER_ADOPTION}}
~~~

Unfilled template commands are not executable instructions. Historical successful use does not establish current authorization or suitability.

## Verification

What to check: {{ACCEPTANCE_SCOPE}}  
Evidence/output location: {{REFERENCE}}  
Actually tested on: {{REVISION_ENVIRONMENT_DATE_OR_NOT_TESTED}}  
Known limits: {{LIMITS}}

## Failure handling and recovery

{{OBSERVABLE_FAILURES_STOPPING_CONDITIONS_RECOVERY_AND_ROLLBACK}}

Recovery validation: {{EVIDENCE_OR_NOT_TESTED}}

## Related records

{{DECISION_REQUIREMENT_STATE_AND_TECHNICAL_REFERENCES}}

Keep operational instructions aligned with their current scope. Archive or explicitly label obsolete procedures.

