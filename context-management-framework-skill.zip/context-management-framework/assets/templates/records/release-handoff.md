# {{RELEASE_ID}} — {{HANDOFF_TITLE}}

Template status: unfilled.  
Owner scope: {{SCOPE_ID}}  
Maintainer: {{MAINTAINER_OR_ROLE}}  
Handoff status: draft  
Prepared: {{DATE_AND_TIMEZONE}}

## What this identifies

{{EXACT_RELEASE_COMPOSITION_OR_DOCUMENTATION_REVISION}}

Selection/release decision: {{REFERENCE_OR_NOT_SELECTED}}  
Package/storage location: {{REFERENCE_OR_NOT_CREATED}}  
Package identity/manifest/checksum: {{REFERENCE_OR_NOT_RECORDED}}

## Contents and exclusions

Included: {{CONTENTS}}  
Required companion files/relative layout: {{REQUIREMENTS}}  
Not included and how to obtain it: {{DEPENDENCIES_AND_LOCATIONS_OR_NONE}}

A source repository or asset ZIP is not automatically a complete environment/data backup.

## Destination instructions

Environment/prerequisites: {{REFERENCE}}  
Entry point/working directory: {{PATH}}  
Load/run/rebuild instructions: {{CANONICAL_PROCEDURE}}  
Input/configuration revisions: {{IDENTITIES}}

## Changes and compatibility

{{CHANGE_SUMMARY_AND_DECISION_REFERENCES}}

## Verification and limits

Source checks actually performed: {{SCOPE_EVIDENCE_OR_NOT_PERFORMED}}  
Extraction/rebuild checks actually performed: {{EVIDENCE_OR_NOT_PERFORMED}}  
Destination runtime/physical validation: {{EVIDENCE_OR_PENDING}}  
Known limitations and assumptions: {{REFERENCES}}

## Continuation and recovery

Next destination action: {{ACTION}}  
Relevant current state/context: {{REFERENCES}}  
Rollback/previous release: {{REFERENCE_OR_NOT_ESTABLISHED}}

Preserve this release's identity. Later workspace changes require a new release or an explicit separate update rather than silently changing historical reports.

