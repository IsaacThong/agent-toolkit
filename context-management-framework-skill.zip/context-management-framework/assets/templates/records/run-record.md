# RUN-{{SCOPE_ID}}-001 — {{RUN_TITLE}}

Template status: unfilled.  
Owner scope: {{SCOPE_ID}}  
Operator/task: {{ACTOR_AND_TASK_ID}}  
Run status: not run  
Run date/time and timezone: {{DATE_OR_NOT_RUN}}

## Purpose and acceptance scope

{{QUESTION_OR_COMPARISON_AND_CRITERIA}}

## Exact inputs

| Input | Owning source | Revision/hash/identity | Local availability |
| --- | --- | --- | --- |
| {{INPUT}} | {{PRODUCER_AND_PATH_OR_STORAGE}} | {{IDENTITY_OR_UNKNOWN}} | {{LOCATION_OR_UNAVAILABLE}} |

Code/configuration identity: {{REPOSITORY_AND_REVISION_OR_OTHER_IDENTITY}}  
Working changes/ignored inputs: {{PATCH_SNAPSHOT_OR_EXPLICIT_UNRECORDED_LIMIT}}  
Environment/tool identity: {{VERSIONS_OR_ENVIRONMENT_MANIFEST}}  
Consumer-specific overrides: {{OVERRIDES_SCOPE_AND_REASON_OR_NONE}}

A current-state pointer alone is not an immutable run input identity.

## Method and commands

{{METHOD_CONDITIONS_COMMANDS_AND_REPRODUCTION_REFERENCE}}

## Outputs and evidence

{{OUTPUT_LOCATIONS_VERSIONS_AND_AVAILABILITY}}

## Actual result

{{RESULT_OR_NOT_RUN}}

Verification scope: {{SCOPE_OR_NOT_PERFORMED}}  
Comparison/acceptance outcome: {{PASS_FAIL_PARTIAL_OR_NOT_EVALUATED}}  
Limitations and assumptions: {{REQUIREMENT_AND_ASSUMPTION_REFERENCES}}

A check passed only within its recorded scope and conditions.

## Interpretation and follow-up

{{CONCLUSIONS_AFFECTED_DECISIONS_AND_REMAINING_WORK}}

Correction/supersession reference: {{REFERENCE_OR_NONE}}

Preserve the actual input identities even if new assets are selected later. Correct invalid conclusions explicitly rather than silently assigning the old result to new inputs.

