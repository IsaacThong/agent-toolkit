# {{TECHNICAL_TOPIC}}

Template status: unfilled.  
Owner scope: {{SCOPE_ID}}  
Maintainer: {{MAINTAINER_OR_ROLE}}  
Document status: draft  
Updated: {{UPDATED_AT}}  
Applies to: {{COMPONENT_AND_REVISION_OR_CONDITIONS}}

## Purpose and question

{{WHAT_THIS_RECORD_EXPLAINS}}

## Sources and method

{{PRIMARY_SOURCES_OBSERVATIONS_METHOD_AND_IDENTITIES}}

Record dates/revisions for version-sensitive claims and evidence availability.

## Findings

{{OBSERVATIONS_AND_SUPPORTING_REFERENCES}}

## Interpretation and uncertainty

{{WHAT_THE_EVIDENCE_SUPPORTS_AND_WHAT_REMAINS_ASSUMED_OR_UNKNOWN}}

## Consequences and decisions

{{DECISION_REQUIREMENT_ASSUMPTION_AND_AFFECTED_CONSUMER_REFERENCES}}

Keep canonical decisions/assumptions in their owning records. This note supplies detail and evidence.

## Procedure or reproduction reference

{{CANONICAL_PROCEDURE_OR_COMMAND_REFERENCE_OR_NOT_APPLICABLE}}

## Status and follow-up

{{IMPLEMENTED_PLANNED_OR_PENDING_ITEMS_AND_EVIDENCE}}

Replaces/superseded by: {{REFERENCE_OR_NONE}}

Suggested document status: draft, active, historical, superseded. Clearly label dated findings that should not be used as current operating instructions.

