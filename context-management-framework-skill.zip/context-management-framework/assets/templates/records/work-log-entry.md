## {{DATE_TIME_AND_TIMEZONE}} — {{EVENT_TITLE}}

Owner scope: {{SCOPE_ID}}  
Task / actor: {{TASK_ID_AND_ACTOR}}  
Outcome: {{DOCUMENTED_PROPOSED_IMPLEMENTED_VERIFIED_FAILED_OR_OTHER}}

Change: {{PREVIOUS_STATE_AND_RESULTING_STATE}}  
Reason / decision reference: {{REQUIREMENT_OR_DECISION_ID_AND_LOCATION}}  
Input/configuration/code identity: {{VERSION_HASH_COMMIT_OR_WORKING_STATE_REFERENCE}}  
Verification actually performed: {{SCOPE_RESULT_AND_EVIDENCE_OR_NOT_RUN}}  
Remaining work: {{ITEMS_OR_NONE}}  
Recovery/correction reference: {{REFERENCE_OR_NOT_APPLICABLE}}

Template entry: fill and append it to the owning work log only for an actual event. Historical facts retain their original scope; explicitly annotate consequential corrections.

