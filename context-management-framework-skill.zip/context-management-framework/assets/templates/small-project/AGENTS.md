# Working instructions for {{PROJECT_NAME}}

Template source: these instructions apply after adoption into the intended project. While editing this template kit, placeholders are not live commands or established project facts.

## Reading and authority

- Read README.md before substantive work. It owns current state, requirements, decisions, assumptions and short history.
- Read authoritative configurations, source data and relevant evidence before relying on technical values or conclusions.
- If a task checkpoint exists, use the one explicitly associated with this task. It is unfinished execution state, not a replacement for project knowledge.
- Current user instructions and applicable higher-priority instructions govern the task. Historical instructions describe their dated scope and are not automatic authorization for new work.

## Working routine

- Establish the task's objective, scope and working state. Preserve unrelated work.
- Use the working directory and actual commands recorded in README. Do not execute unfilled template commands.
- Identify durable changes during authorized work and update the owning README sections at coherent work, verification or handoff boundaries. Bring an update forward when explicitly requested, and record consequential corrections before dependent work proceeds. Preserve scope, status and evidence; follow the latest user limits.
- Check evidence, then discuss consequential gaps before dependent work and surface new issues when discovered. Keep skipped questions unresolved, continue independent work, and record agreed premises separately from unknowns. User agreement to an estimate does not validate it; do not repeatedly reopen deferred questions without new relevance.
- Preserve older applicable constraints and rejected approaches that still matter. Read their sources as needed rather than relying only on recent conversation.
- Keep parameter values in the owning configuration; reference them from context.
- Run verification appropriate to the change. Record actual commands/results, input versions and limitations. Do not rerun completed checks solely to recreate context.
- Update only affected current-state/history sections. If already accurate and sufficient, report no changes without timestamp churn or activity-only entries. Retain meaningful new verification or requested review evidence. Do not claim acceptance, implementation or verification that did not occur, or ask again about authorized updates.
- Use a separate checkpoint only when unfinished work is too detailed for the short project state/plan. Keep one per workstream.

## Project-specific instructions

Working directory: {{WORKING_DIRECTORY}}  
Build/run: {{COMMAND_OR_NOT_APPLICABLE}}  
Verification: {{COMMAND_AND_SCOPE_OR_NOT_APPLICABLE}}  
Preservation/interface constraints: {{APPLICABLE_CONSTRAINT_REFERENCES}}

