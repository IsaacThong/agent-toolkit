# {{PROJECT_NAME}}

Template status: unfilled. Replace placeholders and remove unused rows before adopting.  
Project ID: {{PROJECT_ID}}  
Maintainer: {{MAINTAINER_OR_ROLE}}  
Documentation updated: {{UPDATED_AT}}

## Purpose and scope

{{OBJECTIVE_AND_EXPECTED_RESULT}}

In scope: {{IN_SCOPE}}  
Outside this task/project: {{OUT_OF_SCOPE}}

## Start here

Read this file and [the working instructions](AGENTS.md). Follow the authoritative references below for technical details. A separate checkpoint is optional when substantial unfinished work needs it.

## Authority map

| Information | Authoritative location |
| --- | --- |
| Current state, requirements, decisions, assumptions and short history | The labelled sections in this README |
| Actual parameter values and units | {{CONFIGURATION_OR_SOURCE_DATA_LOCATION}} |
| Implementation | {{IMPLEMENTATION_ENTRY_POINT}} |
| Test/measurement results | {{EVIDENCE_LOCATION_AND_AVAILABILITY}} |
| Working rules | [AGENTS.md](AGENTS.md) |

Use one location for each claim. If a section moves to another file, replace it here with a reference rather than maintaining two copies.

## Use and verify

Working directory: {{WORKING_DIRECTORY}}  
Run/build command: {{COMMAND_OR_NOT_APPLICABLE}}  
Relevant check and its scope: {{CHECK_OR_NOT_APPLICABLE}}  
Dependencies/environment: {{REQUIREMENTS_OR_ENVIRONMENT_REFERENCE}}

Commands are unfilled authoring fields. Do not execute placeholder commands.

## Current state

| Item | Present selection/status | Evidence and last verification |
| --- | --- | --- |
| Selected code/configuration/input revision | {{REVISION_OR_UNKNOWN}} | {{SOURCE_OR_NOT_RECORDED}} |
| Implemented capability | {{CAPABILITY_OR_NOT_IMPLEMENTED}} | {{CHECK_SCOPE_DATE_AND_RESULT_OR_NOT_RUN}} |
| Experimental work | {{CANDIDATE_OR_NONE}} | {{STATUS_AND_LIMITS}} |
| Open questions / known limitations | {{QUESTIONS_LIMITATIONS_OR_NOT_ASSESSED}} | {{SOURCE_AND_IMPACT}} |
| Next project milestone | {{MILESTONE_AND_PROPOSED_OR_SELECTED_STATUS}} | {{BASIS_AND_DEPENDENCIES}} |

Document editing is not verification. Keep this section current; dated past states belong in the change history.

## Requirements and constraints

| ID | Requirement and scope | Status | Source and acceptance criterion |
| --- | --- | --- | --- |
| REQ-{{PROJECT_ID}}-001 | {{REQUIREMENT}} | proposed | {{SOURCE_AND_ACCEPTANCE_CRITERION}} |

Mark applicable requirements active only when their basis is established. Older active constraints still apply until explicitly superseded.

## Engineering decisions

### DEC-{{PROJECT_ID}}-001 — {{DECISION_TITLE}}

Status: proposed  
Owner: {{PROJECT_ID}}  
Question/context: {{QUESTION}}  
Choice: {{PROPOSED_OR_ACTUAL_CHOICE}}  
Basis/source: {{USER_CHOICE_OR_SCOPED_DESIGN_DECISION_OR_EXTERNAL_REQUIREMENT}}  
Reason and alternatives: {{RATIONALE_AND_ALTERNATIVES}}  
Consequences/affected work: {{IMPACT}}  
Evidence and limits: {{REFERENCES_AND_UNCERTAINTY}}  
Supersedes/superseded by: {{ID_OR_NONE}}

For a significant change, update status and link the replacement. Do not treat a proposal as implemented or validated.

## Assumptions

Record only premises actually adopted for a scoped purpose. Keep unanswered questions and verification gaps in current state. Omit unused entries; agreement to use an estimate is distinct from validation.

### ASM-{{PROJECT_ID}}-001 — {{ASSUMPTION_TITLE}}

Status: unverified  
Owner/scope: {{PROJECT_ID}} / {{APPLICABILITY}}  
Assumption: {{PREMISE}}  
Parameter/source reference: {{OWNING_CONFIGURATION_REFERENCE_OR_NOT_APPLICABLE}}  
Basis and uncertainty: {{BASIS_AND_LIMITS}}  
Consumers: {{AFFECTED_METHODS_OR_RESULTS}}  
Validation needed: {{METHOD_AND_ACCEPTANCE_SCOPE}}  
Evidence/replacement: {{REFERENCE_OR_NONE}}

Values remain in their owning configuration. Accepting a design does not validate its assumptions.

## Short change history

No completed changes are recorded by this starter. Add actual dated entries:

~~~text
Date / task / actor:
Change and outcome:
Reason or decision reference:
Verification performed and evidence:
Input/code/configuration identity:
Remaining work or recovery reference:
~~~

Keep useful historical outcomes identifiable. Add explicit corrections when necessary; do not silently change what an earlier run used.

## Continuing unfinished work

Next project milestone is recorded above. If exact execution state becomes substantial, add a task checkpoint from the framework's optional records and identify it here.

Active checkpoint reference: {{PATH_OR_NONE}}

Split this README into context records only when sections become difficult to maintain.

