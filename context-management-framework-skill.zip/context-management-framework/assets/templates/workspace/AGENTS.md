# Working instructions for {{WORKSPACE_NAME}}

Template source: adopt and fill these instructions before treating them as live workspace guidance.

## Workspace boundary

- Read README.md for the project catalog, then context/README.md for authority and reading order.
- Read the relevant project's entry point, current-state authority, requirements, decisions and assumptions before substantive work there.
- Nested project instructions add local working details. Current user instructions and applicable higher-priority instructions govern the task.
- Workspace records own shared conventions and integration selection. Child projects own their technical inputs, implementation and evidence.
- Do not infer a child project's current state from this workspace's old history or another project's summary.

## Working and ownership

- Establish the task's scope, owning project(s), real working state and source/configuration authority.
- Preserve unrelated work and coordinate edits to shared authorities across concurrent workstreams.
- Identify durable changes during authorized work and update their owning records at coherent work, verification or handoff boundaries. Bring updates forward when explicitly requested; record consequential corrections before dependent work proceeds. Preserve scope, status and sources, following the latest user limits.
- Check evidence and discuss consequential gaps before dependent work; surface new issues when discovered. Keep skipped questions unresolved and continue independent work. Record adopted premises separately from unknowns; agreement to use an estimate does not validate it. Reopen deferred questions only when newly relevant.
- Reference technical values from their owner. Mark consumer-specific overrides explicitly.
- For cross-project work, identify producer/consumer interfaces and exact input revisions. Retain historical run identity when inputs change.
- Keep current state free of obsolete current claims. Keep operational instructions consistent with their owning configuration.
- Verify appropriately, record actual results and limits, and avoid redundant reruns without a change/failure/uncertainty requiring them.
- Use checkpoints only for substantial unfinished execution. Keep a project task near its owner; use workspace-level task records for cross-project work.
- If affected records are already accurate and sufficient, report no changes without timestamp churn or activity-only log entries. Record meaningful new evidence or requested reviews, and add history only when worth retaining. Do not copy narratives into every scope or ask again about authorized updates.
- Do not invent completed work, measurements or acceptance. A historical authorization is not automatic permission for a new task.

## Workspace-specific conventions

Shared rules/source: {{REQUIREMENT_AND_INTERFACE_REFERENCES}}  
Working directories: {{PROJECT_SPECIFIC_OR_SHARED_COMMAND_SOURCE}}  
History arrangement: {{PARENT_OR_INDEPENDENT_REPOSITORIES}}  
Preservation requirements: {{REFERENCES}}

