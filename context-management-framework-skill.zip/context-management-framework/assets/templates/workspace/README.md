# {{WORKSPACE_NAME}}

Template status: unfilled.  
Workspace ID: {{WORKSPACE_ID}}  
Maintainer: {{MAINTAINER_OR_ROLE}}  
Updated: {{UPDATED_AT}}

## Purpose

{{WORKSPACE_PURPOSE_AND_BOUNDARY}}

The workspace owns navigation, shared requirements and integration/composition state. Each project owns its implementation, technical values, decisions, assumptions and evidence.

## Start here

1. [Workspace instructions](AGENTS.md).
2. [Context index and authority map](context/README.md).
3. [Workspace current state](context/current_state.md) and [shared requirements](context/requirements.md).
4. The target project's own entry point, current state and applicable records.

Read the projects relevant to the task. Do not load every project/archive for unrelated work.

## Project catalog

This table owns project navigation and responsibility. Child records own their detailed state.

| Project ID | Purpose / owner-maintainer | Location | Context/state entry point | Repository or storage | Depends on |
| --- | --- | --- | --- | --- | --- |
| {{PROJECT_ID}} | {{PURPOSE_AND_MAINTAINER}} | {{PROJECT_PATH}} | {{ENTRY_AND_STATE_PATHS}} | {{REPOSITORY_OR_PARENT_HISTORY_OR_STORAGE}} | {{PRODUCERS_OR_NONE}} |

[Adding and grouping projects](projects/README.md) explains the starter arrangement. Existing grouping such as components/component-a/ can be retained; catalog actual paths instead of assuming every project lives under projects/.

## Shared context

- [Selected composition and integration status](context/current_state.md).
- [Shared requirements](context/requirements.md).
- [Workspace decisions](context/decisions/README.md).
- [Workspace assumptions](context/assumptions.md).
- [Integration/interface records](context/docs/README.md).
- [Workspace work log](context/logs/work-log.md).

## Source and recovery scope

History arrangement: {{ONE_REPOSITORY_OR_INDEPENDENT_PROJECT_REPOSITORIES}}  
Shared assets/evidence: {{LOCATIONS_VERSIONS_AND_ACCESS_REFERENCES}}  
Backup/recovery documentation: {{REFERENCE_OR_NOT_ESTABLISHED}}

If project folders are excluded from management Git, record how each project is stored/versioned and how to obtain it. A management-only clone is not a complete project or machine backup.

## Working entry points

{{WORKSPACE_LEVEL_COMMANDS_OR_LINKS_TO_CANONICAL_TOOL_READMES}}

Keep project-specific run/build commands in the owning project's instructions. Keep installed-version and release claims in the owning state record rather than copying them into this overview.

