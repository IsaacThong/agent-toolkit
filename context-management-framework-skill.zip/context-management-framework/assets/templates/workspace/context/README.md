# {{WORKSPACE_NAME}} context index

Template status: unfilled.  
Owner scope: {{WORKSPACE_ID}}  
Maintainer: {{MAINTAINER_OR_ROLE}}  
Updated: {{UPDATED_AT}}

## Reading order

1. [Workspace map/project catalog](../README.md).
2. [Workspace composition and status](current_state.md).
3. [Applicable shared requirements](requirements.md).
4. The relevant child's declared context/state and its applicable decisions/assumptions.
5. Relevant [workspace decisions](decisions/README.md), [assumptions](assumptions.md) and [interface/integration records](docs/README.md).

The [work log](logs/work-log.md) is dated history. It does not replace current selections.

## Authority map

| Information | Owner/source |
| --- | --- |
| Project catalog and documentation paths | [Workspace README](../README.md) |
| Current workspace composition and integration status | [current_state.md](current_state.md) |
| Shared requirements/conventions | [requirements.md](requirements.md) and named specifications |
| Cross-project design choices | [Decision register](decisions/README.md) and its records |
| Workspace-owned assumptions | [assumptions.md](assumptions.md) |
| Actual child technical values and results | The owning child's named configuration/data/evidence |
| Interface details | The named canonical contract listed in [technical records](docs/README.md) |
| Dated workspace actions | [Work log](logs/work-log.md) |
| Working rules | [Workspace AGENTS](../AGENTS.md) and applicable child instructions |

If a machine-readable manifest already selects the workspace composition, name it here as authority and avoid an independently maintained selection in Markdown.

## Enduring context references

Shared constraints and decisions that future tasks should consult: {{IDS_AND_SOURCE_PATHS_OR_NOT_YET_SELECTED}}

List relevant records and applicability, not another independent copy of their facts. Old active constraints remain relevant; explicitly superseded choices remain history.

## Active cross-project work

Task IDs, owners and optional checkpoint paths: {{REFERENCES_OR_NONE}}

Project-local unfinished work belongs to the child's own task records. Identify the task explicitly instead of choosing a record by modification time.

## Unavailable or external material

{{REFERENCES_REQUIRING_ANOTHER_REPOSITORY_ASSET_TRANSFER_OR_MACHINE_OR_NONE}}

A repository snapshot cannot establish the current live state of an external machine. State what was observed, when, and where evidence is available.

