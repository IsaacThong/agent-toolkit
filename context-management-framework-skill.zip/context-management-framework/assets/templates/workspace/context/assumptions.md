# {{WORKSPACE_NAME}} shared assumptions

Template status: unfilled.  
Owner scope: {{WORKSPACE_ID}}  
Maintainer: {{MAINTAINER_OR_ROLE}}  
Updated: {{UPDATED_AT}}

Record only workspace-owned or integration assumptions. Link to child assumptions instead of copying them.

An assumption is an adopted premise, not merely missing information or an unperformed check. Keep those gaps in workspace current state; omit unused entries. Agreement to use an estimate does not validate it.

## Shared assumptions

### ASM-{{WORKSPACE_ID}}-001 — {{TITLE}}

Status: unverified  
Assumption: {{PREMISE}}  
Scope/conditions: {{AFFECTED_COMPOSITION_OR_INTERFACES}}  
Basis/source: {{REFERENCE_AND_UNCERTAINTY}}  
Owning parameter/configuration reference: {{REFERENCE_OR_NOT_APPLICABLE}}  
Consumers: {{PROJECTS_RUNS_OR_RESULTS}}  
Validation needed: {{METHOD_AND_ACCEPTANCE_SCOPE}}  
Evidence and verified conditions: {{REFERENCE_OR_NOT_VALIDATED}}  
Last assessed: {{DATE_OR_NOT_ASSESSED}}  
Supersedes/superseded by: {{ID_OR_NONE}}

Suggested status: unverified, supported, falsified, superseded.

An accepted integration decision does not validate the assumptions it consumes.

