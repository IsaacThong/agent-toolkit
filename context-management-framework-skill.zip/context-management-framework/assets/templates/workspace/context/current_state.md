# {{WORKSPACE_NAME}} current state

Template status: unfilled.  
Owner scope: {{WORKSPACE_ID}}  
Maintainer: {{MAINTAINER_OR_ROLE}}  
Record updated: {{UPDATED_AT}}

This file owns selected workspace composition and integration status. It does not independently maintain every child's parameters, capabilities or verification results.

## Selected composition

| Project ID | Exact selected revision/configuration | Owning state/source reference | Availability |
| --- | --- | --- | --- |
| {{PROJECT_ID}} | {{REVISION_OR_UNKNOWN}} | {{CHILD_STATE_OR_SOURCE}} | {{LOCAL_SHARED_OR_UNAVAILABLE}} |

Record each repository's revision separately when projects have independent histories. Identify dirty/ignored/external inputs where they affect reproducibility.

## Workspace-owned infrastructure or conventions

| Item owned here | Selection/status | Source and last verification |
| --- | --- | --- |
| {{SHARED_ITEM_OR_NONE}} | {{VALUE_REFERENCE_OR_UNKNOWN}} | {{SOURCE_DATE_SCOPE_OR_NOT_VERIFIED}} |

If another project owns shared environment information, reference that project's state rather than maintaining a second inventory.

## Integration status

| Interface/composition | Exact inputs/revisions | Result | Verified when/by | Evidence and limits |
| --- | --- | --- | --- | --- |
| {{INTEGRATION_OR_NOT_ESTABLISHED}} | {{INPUT_IDENTITIES}} | not run | not recorded | {{REFERENCE_OR_NONE}} |

A child's successful checks do not automatically establish integrated behavior.

## Active candidates, limitations and blockers

Experimental composition: {{CANDIDATE_OR_NONE}}  
Workspace assumption references: {{ASSUMPTION_IDS_OR_NONE}}  
Known limitations/blockers: {{LIMITATIONS_OR_NOT_ASSESSED}}

Open/deferred questions and impact: {{QUESTIONS_OR_NONE_IDENTIFIED}}

Candidates do not replace the selected composition until selection is actually recorded.

## Next shared milestone

{{MILESTONE_AND_DEPENDENCIES}}

Status and basis: {{PROPOSED_OR_SELECTED_AND_SOURCE}}

Detailed unfinished execution belongs in an optional identified task checkpoint. Dated past states belong in history.

