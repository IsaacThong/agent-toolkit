# {{WORKSPACE_NAME}} shared decision register

Owner scope: {{WORKSPACE_ID}}  
Maintainer: {{MAINTAINER_OR_ROLE}}

No accepted decisions are established by this starter.

## Records

| ID | Topic | Canonical record | Affected projects |
| --- | --- | --- | --- |
| {{DECISION_ID}} | {{TITLE}} | {{RECORD_PATH}} | {{PROJECT_IDS}} |

Each record owns its rationale, status, acceptance basis and supersession. This register is navigation.

Workspace decisions cover shared conventions, composition and cross-project trade-offs. A child-specific implementation choice belongs to the child. Name one owner for a cross-project choice and identify affected consumers.

Use the optional decision template for a substantive record. Do not create an approval requirement beyond what the task or applicable instructions actually establish.

