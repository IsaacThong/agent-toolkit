# {{WORKSPACE_NAME}} integration and shared technical records

Owner scope: {{WORKSPACE_ID}}  
Maintainer: {{MAINTAINER_OR_ROLE}}

## Index

| Topic/record | Owning scope | Canonical location |
| --- | --- | --- |
| {{TOPIC_OR_RECORD_ID}} | {{OWNER}} | {{PATH}} |

Use this area for genuinely shared interface contracts, integration run records and workspace-level explanations. Child implementation details and tool usage remain with their owner.

When recording integrated results, identify exact child inputs/configurations, code/environment, method, evidence and limits. Prior results retain their actual inputs after current selection changes.

Optional interface, procedure, technical-note and run-record templates are provided by the framework.

