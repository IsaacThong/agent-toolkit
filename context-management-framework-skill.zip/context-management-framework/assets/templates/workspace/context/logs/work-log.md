# {{WORKSPACE_NAME}} work log

Owner scope: {{WORKSPACE_ID}}  
Maintainer: {{MAINTAINER_OR_ROLE}}

No completed work is recorded by this starter.

Record workspace/integration changes here. Child-local work belongs to the child's log; reference it when a workspace event depends on it.

## Entry format

~~~text
Date/time and timezone:
Task / actor:
Outcome: documented / proposed / implemented / verified / failed / other
Composition or shared change:
Reason / decision reference:
Affected projects and input identities:
Verification performed and evidence:
Remaining work or recovery reference:
~~~

History does not replace current-state selection. Preserve original run/input identity and explicitly annotate consequential corrections.

