# {{WORKSPACE_NAME}} shared requirements

Template status: unfilled.  
Owner scope: {{WORKSPACE_ID}}  
Maintainer: {{MAINTAINER_OR_ROLE}}  
Updated: {{UPDATED_AT}}

Record requirements that genuinely cross project boundaries. Project-local obligations belong to their owning project.

## Shared requirements

### REQ-{{WORKSPACE_ID}}-001 — {{TITLE}}

Status: proposed  
Requirement: {{OBLIGATION_OR_SHARED_CONVENTION}}  
Applies to: {{PROJECTS_INTERFACES_AND_CONDITIONS}}  
Source/basis: {{SOURCE}}  
Acceptance criterion: {{OBSERVABLE_CRITERION}}  
Verification reference/status: {{EVIDENCE_OR_NOT_PERFORMED}}  
Affected owners/consumers: {{SCOPES}}  
Supersedes/superseded by: {{ID_OR_NONE}}

Suggested status: proposed, active, superseded, retired.

Declare units, frames, timing or interface conventions in the appropriate shared specification when needed. Do not invent values or silently convert an old preference into a requirement for every future project.

