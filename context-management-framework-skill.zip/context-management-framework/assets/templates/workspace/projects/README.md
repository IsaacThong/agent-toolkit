# Adding projects to this workspace

The root README owns the project catalog. This file explains how to add a project; do not maintain a second catalog here.

1. Choose a meaningful project boundary and assign a stable project ID and maintainer.
2. Copy the contents of the framework's templates/project starter into the new project directory, or adopt its roles in an existing project.
3. Fill the project's entry points, authority map, current state, requirements and source/configuration ownership.
4. Add its actual location, documentation/state entry points, repository/storage and dependencies to the root catalog.
5. Define interfaces and exact input identities when projects exchange data.
6. Keep local task checkpoints near their owning project. Only cross-project task state belongs at workspace level.

## Layout choices

A project can live under projects/name/, a subject group such as components/component-a/, or an existing directory. Documentation roles remain the same. Ordinary source/helper folders do not all need independent project context.

## History and assets

The workspace can use one Git repository or independent project repositories. Make the arrangement explicit. If a management repository excludes project folders, record each project's separate history/storage and retrieval instructions.

A pointer to a remote repository or large dataset is not an automatic download or synchronization mechanism.

