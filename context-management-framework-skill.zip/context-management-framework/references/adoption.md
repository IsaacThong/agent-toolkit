# Adopt the framework

Use [the specification](framework.md) for authority rules. Adoption is a documentation task with a bounded scope; adopting a template does not authorize rebuilding assets, installing software or changing a deployment.

## New small project

1. Copy the contents of ../assets/templates/small-project into an empty project folder.
2. Replace project ID/name, maintainer, purpose, source/configuration locations and commands.
3. Fill the README's current-state, requirements, decision and assumption sections from actual information. Delete template rows when unused.
4. Keep the short change history in the README until it becomes cumbersome.
5. Copy the optional checkpoint from ../assets/templates/records only for substantial unfinished work.

A project with one folder does not need a context hierarchy simply to satisfy this framework.

## New workspace and subprojects

1. Copy the contents of ../assets/templates/workspace into the workspace root.
2. Fill the workspace catalog, shared requirements and workspace-owned integration state.
3. Copy ../assets/templates/project into each meaningful project location. The default catalog uses projects/, but existing grouping such as components/component-a/ is equally valid.
4. Assign distinct project IDs and owners. Reference each child's state and source/configuration authority.
5. Declare whether Git covers the whole workspace or each project has its own repository. Do not silently exclude project source without a separate storage/history plan.
6. Add interface/run records when components begin consuming each other's data.

The workspace record selects a composition of child revisions. It does not override child measurement results or become another store of child parameters.

## Existing project

1. Inventory existing READMEs, AGENTS files, CONTEXT files, state manifests, decisions, work logs, scripts and generated evidence. Identify scripts that rewrite documentation.
2. Declare each existing authority. Reuse correct records and paths before creating additional files.
3. Establish the actual current selection from sources/evidence. Mark unknowns explicitly; a repository snapshot cannot establish a live machine's current state by itself.
4. Remove contradictory current claims from current-state and operational usage documents. Preserve useful old narrative in dated history. Add correction/supersession references for consequential errors.
5. Keep one current-state authority. If an existing JSON manifest selects the current asset, link to it rather than hand-maintaining another selection in Markdown.
6. Keep one context entry point: an existing CONTEXT.md can remain the entry/background document, or adopt context/README.md. A temporary forwarding document contains links, not a second status summary.
7. Introduce decision/assumption IDs when cross-references are useful. Older valid decisions and constraints remain applicable until explicitly changed.
8. Add checkpoints only where unfinished execution needs them.
9. Update documentation writers/generators before changing headings or file structures they depend on.
10. Check changed links and run only verification appropriate to this documentation change.

Do not silently modify frozen packages, revise old results to point to new inputs, or overwrite concurrent/unrelated work.

## Ownership worksheet

| Information | Owning scope | Authoritative location | Maintainer | Consumers |
| --- | --- | --- | --- | --- |
| Workspace conventions | Fill | Fill | Fill | Fill |
| Current release/composition | Fill | Fill | Fill | Fill |
| Technical parameter/configuration | Fill | Fill | Fill | Fill |
| Requirements | Fill | Fill | Fill | Fill |
| Significant decisions | Fill | Fill | Fill | Fill |
| Assumptions | Fill | Fill | Fill | Fill |
| Evidence and run records | Fill | Fill | Fill | Fill |

A logical owner is not necessarily a single permanent editor. Concurrent tasks coordinate edits to a shared authority and maintain separate unfinished-work records.

## Lightweight adoption check

A new reader should be able to answer:

- What is the project for, and who maintains it?
- Which instructions and constraints apply?
- Which revision/configuration is selected, and what remains experimental?
- Where do parameter values and supporting evidence come from?
- Which claims are measured, assumed, inferred or unverified?
- Why were important choices made, and which earlier choices were superseded?
- Which other projects consume the inputs or outputs?
- What was actually verified, on which revision and under which conditions?
- If there is unfinished work, what is the stopping point and next action?
- Are operational instructions consistent with the selected state?

This is a review of the adopted records, not a demand to rerun unrelated engineering tests.

## Expanding a small project

Split one role at a time when its section becomes hard to maintain:

- Current state becomes context/current_state.md.
- Requirements become context/requirements.md.
- Significant decisions become individually identified records.
- Assumptions become context/assumptions.md.
- Growing history becomes context/logs/work-log.md.

Update the README's authority table and replace the moved section with a link. Avoid leaving two editable copies.

## Boundaries of this package

This package provides guidance and templates; it does not automatically migrate an existing workspace.

