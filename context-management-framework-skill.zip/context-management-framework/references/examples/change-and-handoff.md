# Worked example: a terrain change consumed by an energy project

This entire example is fictional. IDs, revisions and evidence references below illustrate the framework; they do not describe any actual project or system.

## Ownership

| Scope | Owns | Consumes |
| --- | --- | --- |
| SAMPLE-VEHICLE | Vehicle parameter configuration and measurement/assumption basis | Physical measurements |
| SAMPLE-TRACK | Terrain sources, selected surface and elevation-processing decisions | Survey inputs |
| SAMPLE-ENERGY | Energy equations, method and run configuration | Vehicle parameters, terrain and trajectory |
| SAMPLE-WORKSPACE | Project catalog, shared coordinate conventions and selected composition | Explicit child revision references |

A mass parameter has its value in the vehicle configuration. ASM-SAMPLE-VEHICLE-001 explains that its loaded-mass value is an unverified estimate. The energy project references that parameter; it does not establish a competing general vehicle mass.

## An older constraint that still matters

REQ-SAMPLE-TRACK-001: preserve the longitudinal elevation behavior used by downstream energy analysis. Status: active. Scope: track reconstruction candidates.

A later task remains subject to this requirement even when it was discussed long ago. The context index points to requirements and relevant accepted decisions, rather than selecting information only by date.

## A proposed decision

DEC-SAMPLE-TRACK-002 proposes candidate surface R2 to reduce short-scale defects. Its record includes the method, alternatives, referenced inputs, expected consequences and remaining validation.

At this point:

- The decision is proposed.
- R2 is experimental.
- R1 remains the selected surface.
- Pending tests are not described as passed.
- The work log can record the proposal and inspection without claiming adoption.

## A run records its actual inputs

RUN-SAMPLE-ENERGY-003 records:

- terrain R1;
- vehicle configuration revision V1, including ASM-SAMPLE-VEHICLE-001;
- trajectory revision P1;
- energy code/configuration revision E1;
- method/environment identity and evidence location;
- its actual outcome and limits.

It remains a result for that combination. Changing a current-state pointer later does not change its inputs.

## Selection after actual review

Suppose the owner subsequently accepts R2 within the task's scope after the relevant checks:

1. Record what actually passed, its scope and evidence.
2. Update DEC-SAMPLE-TRACK-002 with the acceptance basis.
3. Update the track's current-state selection to R2.
4. Identify the energy project as an affected consumer.
5. Log the selection change and reference the decision and evidence.

The workspace selects a new composition only if that integration selection is actually made. The energy project's earlier R1 report is not renamed or relinked to R2.

## Impact review

The energy maintainer reviews whether its conclusions need another run. A new run can be planned without declaring the R1 run invalid as historical evidence.

If the energy project deliberately uses a different mass, record it as a run-specific override with its reason and scope. It does not silently change the vehicle project's authoritative parameter.

## Optional unfinished-task checkpoint

Task: TASK-SAMPLE-ENERGY-004  
Owner: SAMPLE-ENERGY  
Mode: implementation  
Status: waiting

Objective: assess the energy impact of terrain R2.

Completed:
- Identified the previous R1 run and its exact inputs.
- Reviewed the new track decision.

Pending:
- Obtain the separately stored R2 surface.
- Run the relevant energy calculation when the required input is available.

Next action: retrieve the identified R2 artifact; do not substitute another candidate.

The engineering rationale belongs to the decision and run records. This checkpoint only captures unfinished execution.

## Example work-log entry

Date: example date  
Task/owner: TASK-SAMPLE-ENERGY-004 / SAMPLE-ENERGY  
Outcome: dependency review completed; new calculation not run.  
Change: identified R2 as the proposed input for a new comparison.  
Reason: DEC-SAMPLE-TRACK-002.  
Evidence: link to the actual dependency review in an adopted project.  
Remaining: surface availability and new run.  
Historical result: RUN-SAMPLE-ENERGY-003 still refers to R1.

## Example correction

If a later measurement falsifies the loaded-mass estimate:

- update the owning vehicle parameter and the assumption's status/evidence;
- identify the energy runs that used that estimate;
- annotate affected conclusions with the correction and review their applicability;
- retain the old run's input identity;
- perform new verification only where needed.

Recording this correction does not by itself establish a new validated energy result.

