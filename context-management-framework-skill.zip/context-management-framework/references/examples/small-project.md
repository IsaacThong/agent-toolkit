# Small-project example: a CSV summary utility

This is fictional documentation illustrating how context can fit in one README. The script, data, configuration, decisions and results described below are examples, not delivered software or work performed in this repository.

## Project overview

Project ID: SAMPLE-CSV  
Maintainer: example project maintainer  
Purpose: read a CSV file and write a separate summary report.

Implementation entry: main.py. Parameters/input paths: config.json. Working instructions: AGENTS.md. These are illustrative paths in the imagined project, not links to files in this kit.

## Authority

This README owns the current project state, requirements, short decisions, assumptions and change history. Configuration owns parameter values. Identified run outputs own test evidence.

## Current state

- Design is selected; implementation has not started.
- No input format has been verified against a real supplied file.
- No tests have been run.
- Next milestone: obtain a representative input and establish the required columns.

## Requirement

REQ-SAMPLE-CSV-001, active: preserve the original input and write any report separately. Source: fictional user requirement. Acceptance: the input remains unchanged after report generation. Verification has not occurred.

This requirement remains applicable to later edits even when the original conversation is old.

## Decision

DEC-SAMPLE-CSV-001, accepted in this fictional example: initially use the language's standard CSV library. Reason: the current task needs basic row/column processing and no demonstrated external dependency. Alternative: a dataframe library, to reconsider if analysis needs warrant it. Implementation and verification remain pending.

## Assumption

ASM-SAMPLE-CSV-001, unverified: the supplied file will be UTF-8 with a header row. Basis: a preliminary description, not inspection. Validate with the actual sample. The input-path value belongs in config.json rather than being copied here.

## Change history

Example date: recorded the input-preservation requirement and initial library decision. Outcome: documentation/design only. No implementation or verification occurred.

## Optional task state

The next step is simple enough to state here: obtain and inspect the representative input. A separate CHECKPOINT.md is unnecessary at this point.

If later work spans several interrupted steps, an optional checkpoint can record the exact stopping point. The requirement, decision and assumption remain authoritative in this README until intentionally split into their own records.

## Growing the project

Move the relevant sections into dedicated context records only when they become hard to maintain independently. Replace the moved section with a reference; do not leave a second editable copy.

## Later maintenance example

During a later authorized work unit, an optional export feature is proposed and an input-format question remains unanswered. The user asks to update context mid-task. The agent records the proposal and open question in the existing README immediately, retaining their statuses and leaving implementation/verification pending.

A repeated update request with no new information produces a brief no-change response. It does not change timestamps or add an activity-only log entry. Once the work unit produces meaningful verification evidence, the agent updates affected state and evidence references at that boundary without another save confirmation. A consequential correction is recorded before dependent work proceeds. A minor refactor that leaves the records accurate needs no documentation edit.
