# Context framework specification

Status: finalized framework; copied templates require project-specific adoption.

## 1. Purpose and scale

Make it possible for a person or agent to establish the current project, applicable constraints, reasoning, evidence and unfinished work without reconstructing an entire conversation.

Use two deployment patterns:

- **Small project:** README contains current state, requirements, decisions, assumptions and a short change history. AGENTS contains working instructions.
- **Workspace:** the workspace owns navigation, shared constraints and cross-project composition. Each meaningful subproject owns its own implementation context. A larger standalone project uses the same project starter without a parent.

A folder deserves independent context when it has independent state, inputs, decisions, interfaces or maintenance responsibilities. Ordinary utility folders do not automatically need context files.

## 2. Ownership

Distinguish these roles:

- **Owner scope:** the component/project whose record is authoritative.
- **Maintainer:** the person or team role responsible for keeping that scope coherent.
- **Current editor/task:** the workstream currently changing particular files. Editing does not transfer ownership or prove approval.
- **Consumers:** other components that use the owner's data, interface or result.

The workspace catalog names owners and documentation entry points. A subproject's context index identifies its authoritative records and external dependencies.

Every fact has one authoritative home. Other records may give a short, scoped explanation and a reference, but should not independently maintain the same technical values.

## 3. Information authority

| Information | Authority |
| --- | --- |
| Actual parameter values, units and program inputs | Owning configuration, specification or source data |
| Measured observations | Identified measurement/test record, with method, date and limits |
| Current selected revision and verification status | Declared current-state record |
| Active requirements and constraints | Requirements/specification or its declared README section |
| Engineering choice and rationale | Decision record or declared decisions section |
| Unverified premise, basis and validation needs | Assumption register or declared assumptions section |
| Open questions and verification gaps | Owning current-state/context limitations section |
| Canonical operating procedure | Named technical document or tool README |
| Unfinished work | The task's current checkpoint, if one is useful |
| Dated actions | Work log |
| Agent working procedure | Applicable AGENTS instructions |
| Generated search/graph/summary material | Derived navigation only; follow its source references |

This is an information-responsibility map, not a replacement for the instruction hierarchy of an AI client. Current user instructions and applicable higher-priority instructions still govern the task.

When sources conflict, establish which source owns the claim, inspect its revision/status/evidence, and record the reconciliation. Do not select a claim merely because its file is newest.

## 4. Current state versus history

Current state describes the present selection and known status, including:

- selected configuration/asset/build or explicitly unknown selection;
- entry points and source references;
- implemented capabilities versus active experiments;
- verification by scope, version, date and evidence;
- known limitations, unresolved assumptions and blockers;
- the next project milestone, distinct from an active task's next command.

Keep old milestone narratives in history/decision records. Do not retain an obsolete statement as an unqualified current instruction.

An edit timestamp is not a verification timestamp. Builds, automated tests, deployment checks, runtime observations and physical measurements establish different verification scopes.

Selection, release and verification are separate claims: a selected revision may remain experimental or incompletely verified.

## 5. Requirements, decisions and assumptions

Use stable IDs when records need cross-references. Suggested forms are REQ-SCOPE-001, DEC-SCOPE-001, ASM-SCOPE-001, RUN-SCOPE-001 and TASK-SCOPE-001. Keep the ID when moving or renaming a record.

### Requirements

Record the obligation, its scope, source, applicability and acceptance criterion. Identify project-wide constraints that remain relevant to later work.

Suggested status: proposed, active, superseded, retired.

### Decisions

Record the question, selected option, alternatives, rationale, consequences, evidence, affected components and the decision's source/basis. Identify whether it is a user choice, a design decision made within the task's scope, or an external requirement.

Suggested status: proposed, accepted, rejected, superseded, withdrawn.

Do not equate a proposal with acceptance. Record the actual basis for acceptance rather than inventing an approval.

Suggested milestones remain proposed until selected on an identifiable basis. Adoption of documentation does not by itself select a new engineering priority.

### Assumptions

Record what is being treated as true, its scope, basis, uncertainty, consumers and validation needed. Link to the configuration parameter when it has a numerical value; the register does not become another parameter store.

Suggested status: unverified, supported, falsified, superseded.

Supported evidence is bounded by its tested conditions. A decision can be accepted while an assumption it depends on remains unverified.

### Questions and resolution

An unknown is missing information; a verification gap is missing evidence of behavior. Neither is an assumption unless a premise is actually adopted for a scoped purpose. Record open questions and limitations in the owning context/current state; record adopted premises in its assumptions section/register. Omit unused sections rather than inventing entries. No separate tracker or category files are required.

Check existing evidence first. Discuss consequential gaps before dependent implementation, explaining the impact and seeking an answer or an agreed provisional approach. Routine scoped choices need no additional approval. A user may defer a question: keep it unresolved, continue independent work and leave dependent work pending without adequate inputs. Skipping or silence does not approve an estimate; agreeing to use one does not validate it.

Surface newly discovered issues when they matter, including during implementation or final review. Once saving or implementation is authorized, record answers, agreed assumptions and remaining questions with their scope. Review affected conclusions or checks without changing historical run inputs. Avoid repeatedly reopening deferred questions without new relevance or evidence.

### Corrections and supersession

- Preserve useful history and original test/input identity.
- Explicitly qualify known-wrong claims and identify affected conclusions.
- Link replacements in both directions when useful.
- An existing log entry may receive an explicit correction annotation; do not silently rewrite its historical outcome.
- Simple erroneous notes can be corrected in place, retaining a correction/history reference where consequential. A separate obsolete document is not always necessary.

Age does not remove a still-applicable constraint. Equally, an old requirement must not be revived after explicit supersession.

## 6. Cross-project dependencies

Consumers reference the owning project and a specific input revision where results depend on it.

The workspace owns shared conventions and integration composition; it does not copy every child parameter or every child's full state. A cross-project decision has one named owner and identifies all affected consumers.

An interface contract identifies the producer, consumer, schema/shape, units, coordinate/time conventions, versioning, validation and failure behavior where relevant.

A saved run records exact input/configuration/code/environment references. A consumer-specific override is explicit, scoped to that consumer/run, and does not silently redefine the producer's source value.

Changing an input triggers impact review, not automatic invalidation or automatic acceptance of every dependent result. Rerun only affected verification where the change or remaining uncertainty justifies it.

## 7. Evidence and reproducibility

For meaningful results, retain:

- input/configuration revisions, IDs or hashes;
- code and environment identity where relevant;
- command/method and conditions;
- output/evidence locations and availability;
- result and its verification scope;
- limitations and remaining work.

Git identifies tracked history, not ignored files, live services, installed applications or external datasets. If a working tree was dirty, record the relevant changes or a reproducible patch/snapshot reference. If Git is unavailable, use another explicit identity.

Keep raw generated output in an appropriate ignored output/evidence location; keep the interpretation and references in durable documentation. Record whether referenced evidence is local-only, separately transferred or available in shared storage.

Do not claim reproduction, successful tests or destination validation that has not occurred.

## 8. Task checkpoints

A checkpoint is optional execution state for substantial unfinished work, not the only store of project knowledge.

It records the objective, current constraints with references, selected inputs, working files, completed verification, stopping point, pending processes and next action.

Place it near its owning project. Use a workspace-level task location only for genuinely cross-project work. Give concurrent workstreams separate task IDs/checkpoints and explicit ownership. Do not use the most recently modified checkpoint as an automatic task selector.

If work already fits clearly in current state and a short plan, another file may be unnecessary. On completion, record durable outcomes in their authoritative records and mark/archive the checkpoint.

## 9. Work logs and releases

The human-readable work log records date, actor/task, change, reason/decision reference, outcome, verification/evidence and relevant version.

A decision can be logged without implementation. A failed experiment can be useful history. Use dates, scope and outcome to avoid treating either as a current instruction.

A separate CHANGELOG is optional and appropriate for concise user-facing release changes. It does not replace detailed decision rationale or run provenance.

Keep exported/frozen releases identifiable. Later workspace changes do not retroactively change what an older package contained or what a prior report tested.

## 10. Update routine

1. At task start, read the relevant entry point, current state and applicable requirements. Establish the current task's scope and real working state.
2. During authorized work, identify durable changes in requirements, findings, decisions, adopted assumptions, important open questions/blockers, selections, implementation, verification or substantial unfinished work. Update their owning records; consult older applicable decisions rather than relying solely on recent chat.
3. Keep a checkpoint only when execution complexity warrants one.
4. Perform appropriate verification and record its actual outcome and limits.
5. Update affected current-state selections/status and consumer references. Update navigation only if locations/ownership changed; update AGENTS only if working rules changed.
6. Add a brief work-log entry for durable changes or evidence worth retaining, or a requested review record. Link detailed evidence rather than copying it.
7. Check the edited records for contradictions, stale operational instructions and broken references.

Consolidate related edits at coherent work, verification or handoff boundaries. Bring updates forward on an explicit request; record consequential corrections before dependent work proceeds within the authorized scope. Follow the latest user limits: a scoped save request can permit documentation edits while engineering implementation remains unapproved. Do not leave meaningful progress unrecorded until the end of a long task merely for batching.

An update request triggers a relevant review, not forced edits. If existing records are accurate and sufficient, report that briefly without timestamp churn, redundant summaries or activity-only log entries. New verification evidence or a meaningful review requested by the user/project instructions can warrant recording even if implementation is unchanged. Routine conversation and minor edits that leave records accurate need no documentation changes.

This routine does not require a decision record for every edit or updates to every document on every task. Adopted AGENTS instructions carry maintenance expectations into ordinary work without repeatedly invoking this skill.

## 11. Adoption and reading

Preserve existing useful history and canonical manifests. A project can retain CONTEXT.md as its entry point or an existing CURRENT_STATE.json as state authority. Declare the mapping and avoid two independently maintained current summaries.

Use project-relative references where possible. For external repositories/assets, record the repository/storage location and version; unavailable assets are not automatically transferred by a note link.

Read progressively: entry point, state, applicable constraints and relevant decisions, then topic/evidence as needed. Do not load every archive, raw log or subproject for an unrelated task.

Optional indexing tools and client integrations can assist navigation. The framework's information responsibilities and manual handoff must work independently of them.

